import Menu from "../views/Menu"

export default function AuthLayout() {
    return(
        <Menu/>
    )
}
