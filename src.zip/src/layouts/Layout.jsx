import Login from "../views/Login"

export default function Layout() {
    return(
        <div>
            <Login />
        </div>
    )
}
