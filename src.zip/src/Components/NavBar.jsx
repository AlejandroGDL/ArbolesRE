import "../Components/NavBar.css";

export default function NavBar() {

    return(
        <div className="NavBar">
            <img src="../src/assets/logo.png" alt="" className="NavBarImg"/>
        </div>
    )
}